package com.example.rescuesquad;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    TextView resuesquadtracking;
    CardView cardView;
    DatabaseHelper myDb;
    EditText admin_id, admin_password;
    TextView textView;
    SQLiteOpenHelper dbhelper;
    SQLiteDatabase db;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        resuesquadtracking=(TextView) findViewById(R.id.textView2);
        admin_id=(EditText) findViewById(R.id.username_login);
        admin_password=(EditText) findViewById(R.id.password_login);
        myDb = new DatabaseHelper(this);
        cardView = (CardView) findViewById(R.id.cv);

        if (myDb == null) {
            myDb.insertAdmin();
        }


        resuesquadtracking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor res = myDb.getAllAdminData();
                if (res.getCount() == 0) {
                    showMessage("Error", "Nothing found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("ADMIN_ID: " + res.getString(0) + "\n");
                    buffer.append("PASSWORD: " + res.getString(1) + "\n\n");

                }
                showMessage("Data", buffer.toString());
            }
        });
        dbhelper = new DatabaseHelper(this);
        db = dbhelper.getReadableDatabase();

    }


    public void admin_submit(View view) {
        String email = admin_id.getText().toString();
        String pass = admin_password.getText().toString();

        cursor = db.rawQuery("SELECT *FROM " + DatabaseHelper.ADMIN_TABLE+ " WHERE " + DatabaseHelper.ADMIN_ID + "=? AND " + DatabaseHelper.ADMIN_PASSWORD + "=?", new String[]{email, pass});
        if (cursor != null) {
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                //Retrieving User FullName and Email after successfull login and passing to LoginSucessActivity
                String _email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.ADMIN_ID));
                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, FirstPage.class);
                intent.putExtra("email", _email);
                startActivity(intent);

                //Removing MainActivity[Login Screen] from the stack for preventing back button press.
                finish();
            } else {
                Toast.makeText(this, "Username or Password Incorrect", Toast.LENGTH_LONG).show();

            }
        }



    }
    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}
