package com.example.rescuesquad;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.support.annotation.Nullable;
import android.util.Log;


/**
 * Created by rinka on 15-02-2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper{

    public static final String DATABASE_NAME = "Rescue.db";
    private static final int databaseVersion = 1;


    //admin_table
    public static final String ADMIN_TABLE = "admin_table";
    public static final String ADMIN_ID = "ADMIN_ID";
    public static final String ADMIN_PASSWORD= "ADMIN_PASSWORD";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null,databaseVersion);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String createTableAdmin = "create table " + ADMIN_TABLE + "(ADMIN_ID TEXT, ADMIN_PASSWORD TEXT)";
            db.execSQL(createTableAdmin);
        }
        catch (SQLException se) {
            Log.v("SQLException",
                    Log.getStackTraceString(se));
        } catch (Exception e) {
            Log.v("Exception",
                    Log.getStackTraceString(e));
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        try {
            // Drop table Admin
            String AdminTableDropQuery = "DROP TABLE IF EXISTS "
                    + ADMIN_TABLE;
            db.execSQL(AdminTableDropQuery);
            // Upgrade database
            onCreate(db);

        } catch (SQLException se) {
            Log.v("SQLException",
                    Log.getStackTraceString(se));
        } catch (Exception e) {
            Log.v("Exception",
                    Log.getStackTraceString(e));
        }

    }

    public void insertAdmin(){
        SQLiteDatabase db=this.getWritableDatabase();
        db.execSQL("INSERT INTO "+ADMIN_TABLE+" (ADMIN_ID,ADMIN_PASSWORD) VALUES ('rescue','rescue')");
    }

    public Cursor getAllAdminData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + ADMIN_TABLE, null);
        return res;
    }
}
